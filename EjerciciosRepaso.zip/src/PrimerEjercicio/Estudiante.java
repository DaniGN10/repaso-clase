package PrimerEjercicio;


public class Estudiante extends Persona {

    private float nota;
    private String asignatura;

    public Estudiante(String ojos, String boca, String trabajo, String pelo, int edad, float nota, String asignatura) {
        super(ojos, boca, trabajo, pelo, edad);
        this.nota = nota;
        this.asignatura = asignatura;
    }

    public float getNota() {
        return nota;
    }

    public void setNota(float nota) {
        this.nota = nota;
    }

    public String getAsignatura() {
        return asignatura;
    }

    public void setAsignatura(String asignatura) {
        this.asignatura = asignatura;
    }
}
