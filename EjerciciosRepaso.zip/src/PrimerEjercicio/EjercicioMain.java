package PrimerEjercicio;

public class EjercicioMain {

    public static void main(String[] args) {

        Persona dani = new Persona("oscuros", "tiene", "es estudiante", "osucro", 19);

        Persona sergio = new Persona("azules", "tiene","es estudiante","oscuro", 17);

        dani.puedeCorrer();
        dani.esMayorDeEdad();
        boolean esMayor = dani.esMayorDeEdadConReturn();
        System.out.println(esMayor);

        dani.setEdad(17);
        System.out.println();
        dani.esMayorDeEdad();

        sergio.setEdad(17);
        System.out.println();
        sergio.puedeConducir();
        sergio.esMayorDeEdad();
        sergio.puedeCorrer();
        boolean tieneTrabajo = sergio.esMayorDeEdadConReturn();
        System.out.println(tieneTrabajo);

        sergio.setTrabajo("es estudiante");
        System.out.println(sergio.tieneTrabajo());

        Estudiante mario = new Estudiante("oscuros", "tiene", "es estudiante", "oscuro", 19, 8, "matemáticas");
        mario.setEdad(23);
        System.out.println();
        sergio.puedeConducir();
        sergio.puedeCorrer();
        sergio.puedeConducir();
        sergio.esMayorDeEdad();

    }
}
