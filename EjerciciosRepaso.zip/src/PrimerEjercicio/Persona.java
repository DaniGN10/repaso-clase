package PrimerEjercicio;

public class Persona {

    protected String ojos;
    protected String boca;
    protected String trabajo;
    protected String pelo;
    protected int edad;

    public Persona(String ojos, String boca, String trabajo, String pelo, int edad) {
        this.ojos = ojos;
        this.boca = boca;
        this.trabajo = trabajo;
        this.pelo = pelo;
        this.edad = edad;
    }

    public String getOjos() {
        return ojos;
    }

    public void setOjos(String ojos) {
        this.ojos = ojos;
    }

    public String getBoca() {
        return boca;
    }

    public void setBoca(String boca) {
        this.boca = boca;
    }

    public String getTrabajo() {
        return trabajo;
    }

    public void setTrabajo(String trabajo) {
        this.trabajo = trabajo;
    }

    public String getPelo() {
        return pelo;
    }

    public void setPelo(String pelo) {
        this.pelo = pelo;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public void puedeCorrer() {
        System.out.println("Si puede");
    }

    public void puedeComer(){
        System.out.println("Si puede comer");
    }

    public void esMayorDeEdad(){
        if (this.edad >= 18) {
            System.out.println("Si es mayor de edad");
        }
        else {
            System.out.println("Es menor de edad");
        }
    }

    public boolean esMayorDeEdadConReturn(){
        if (this.edad >= 18) {
            return true;
        }
        else {
           return false;
        }
    }

    public void puedeConducir() {
        if (this.edad >= 18) {
            System.out.println("Si puede");
        }
        else {
            System.out.println("No puede");
        }
    }

    public boolean tieneTrabajo() {
        if (this.trabajo.equals("es estudiante")) {
            return false;
        }
        else {
            return true;
        }
    }

}
