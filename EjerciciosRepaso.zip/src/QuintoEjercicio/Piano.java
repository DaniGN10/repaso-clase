package QuintoEjercicio;

public class Piano extends Instrumento {

    public Piano(String nombre, String tipo) {
        super(nombre, tipo);
    }
}
