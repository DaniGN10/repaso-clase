package QuintoEjercicio;

public class Guitarra extends Instrumento {

    public Guitarra(String nombre, String tipo) {
        super(nombre, tipo);
    }
}
