package QuintoEjercicio;

public interface Afinable {

    public void afinar();
}
