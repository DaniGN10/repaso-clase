package QuintoEjercicio;

public class InstrumentosMain {

    public static void main(String[] args) {
        Instrumento guitarra = new Instrumento("Guitarra", "Cuerda");
        guitarra.afinar();
    }
}
