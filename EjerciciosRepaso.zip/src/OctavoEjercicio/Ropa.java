package OctavoEjercicio;

public class Ropa extends Producto {

    private String talla;

    public Ropa(String nombre, float precio, String talla) {
        super(nombre, precio);
        this.talla = talla;
    }

    public String getTalla() {
        return talla;
    }

    public void setTalla(String talla) {
        this.talla = talla;
    }

    @Override
    public void DetalleProducto() {
        System.out.println("Producto: {nombre: " + this.getNombre() +", precio: " + this.getPrecio() + ", talla: " + this.talla + "}");
    }

    @Override
    public void calcularDescuento() {
        this.setPrecio((float) (this.getPrecio() * 0.85));
    }
}
