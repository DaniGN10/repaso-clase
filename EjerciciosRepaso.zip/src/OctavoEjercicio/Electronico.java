package OctavoEjercicio;

public class Electronico extends Producto {

    private String marca;

    public Electronico(String nombre, float precio, String marca) {
        super(nombre, precio);
        this.marca = marca;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    @Override
    public void DetalleProducto() {
        System.out.println("Producto: {nombre: " + this.getNombre() +", precio: " + this.getPrecio() + ", marca: " + this.marca + "}");
    }

    @Override
    public void calcularDescuento() {
        if (this.getPrecio() > 500) {
            this.setPrecio((float) (this.getPrecio() * 0.9));
        }
    }

}
