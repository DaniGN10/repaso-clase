package OctavoEjercicio;

import java.util.ArrayList;

public class TiendaMain {

    public static void main(String[] args) {
        ArrayList<Producto> lista = new ArrayList<>();

        Electronico e = new Electronico ("E1", 200, "Samsung");

        Ropa r = new Ropa("R1", 15, "M");

        lista.add(e);
        lista.add(r);

        for (int i = 0; i < lista.size(); i++) {
            lista.get(i).calcularDescuento();
            lista.get(i).DetalleProducto();
        }
    }
}
