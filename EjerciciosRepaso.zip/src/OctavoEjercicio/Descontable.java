package OctavoEjercicio;

public interface Descontable {

    void calcularDescuento();
}
