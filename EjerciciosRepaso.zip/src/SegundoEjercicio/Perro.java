package SegundoEjercicio;

public class Perro extends Mascota {

    public Perro(String name, int edad, String tipo) {
        super(name, edad, tipo);
    }

    @Override
    public void sonido() {
        System.out.println("El perro hace miau");
    }
}
