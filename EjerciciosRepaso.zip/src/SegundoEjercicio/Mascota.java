package SegundoEjercicio;

public class Mascota {

    private String name;
    private int edad;
    private String tipo;

    public Mascota(String name, int edad, String tipo) {
        this.name = name;
        this.edad = edad;
        this.tipo = tipo;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public void sonido() {
        System.out.println("no conozco el sonido");
    }

    @Override
    public String toString() {
        return "Mascota{" +
                "name='" + name + '\'' +
                ", edad=" + edad +
                ", tipo='" + tipo + '\'' +
                '}';
    }
}
