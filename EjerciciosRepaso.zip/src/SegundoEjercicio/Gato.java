package SegundoEjercicio;

public class Gato extends Mascota {

    public Gato(String name, int edad, String tipo) {
        super(name, edad, tipo);
    }

    @Override
    public void sonido() {
        System.out.println("El gato hace miau");
    }
}
