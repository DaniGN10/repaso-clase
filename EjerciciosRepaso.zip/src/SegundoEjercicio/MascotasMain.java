package SegundoEjercicio;

public class MascotasMain {

    public static void main(String[] args) {

        Perro kira = new Perro("Kira", 14, "Perro");

        kira.sonido();

        System.out.println(kira.toString());
    }
}
