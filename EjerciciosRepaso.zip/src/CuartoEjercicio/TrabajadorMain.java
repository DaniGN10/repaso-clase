package CuartoEjercicio;

public class TrabajadorMain {

    public static void main(String[] args) {
        Trabajador camilo = new Trabajador("Camilo", 17);
        camilo.puedeComer();

        boolean puede = camilo.puedeDescansar();
        System.out.println(puede);
    }
}
