package CuartoEjercicio;

public interface FuncionesPersona {

    public void puedeComer();

    public boolean puedeDescansar();
}
