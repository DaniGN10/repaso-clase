package CuartoEjercicio;

public class Trabajador extends Persona {

    public Trabajador(String nombre, int edad) {
        super(nombre, edad);
    }
}
