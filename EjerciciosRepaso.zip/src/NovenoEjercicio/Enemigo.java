package NovenoEjercicio;

public class Enemigo extends Entidad {

    private String nivel;

    public Enemigo(String nombre, int vida, String nivel) {
        super(nombre, vida);
        this.nivel = nivel;
    }

    public String getNivel() {
        return nivel;
    }

    public void setNivel(String nivel) {
        this.nivel = nivel;
    }

    @Override
    public void estadoActual() {
        System.out.println("Producto: {nombre: " + this.getNombre() +", vida: " + this.getVida() + ", nivel: " + this.nivel + "}");
    }
}
