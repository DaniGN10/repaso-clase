package NovenoEjercicio;

import java.util.ArrayList;

public class PersonajesMain {
    public static void main(String[] args) {
        ArrayList<Entidad> lista = new ArrayList<>();

        Aliado a = new Aliado ("Link", 70, "infinita");

        Enemigo e = new  Enemigo ("Ganondorf", 100, "80");

        lista.add(a);
        lista.add(e);

        for (int i = 0; i < lista.size(); i++) {
            lista.get(i).estadoActual();
            lista.get(i).accionRapida();
        }
    }
}
