package NovenoEjercicio;

public interface Interactuable {

    void  accionRapida();
}
