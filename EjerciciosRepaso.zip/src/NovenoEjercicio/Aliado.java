package NovenoEjercicio;

public class Aliado extends Entidad {

    private String energia;

    public Aliado(String nombre, int vida, String energia) {
        super(nombre, vida);
        this.energia = energia;
    }

    public String getEnergia() {
        return energia;
    }

    public void setEnergia(String energia) {
        this.energia = energia;
    }

    @Override
    public void estadoActual() {
        System.out.println("Producto: {nombre: " + this.getNombre() +", vida: " + this.getVida() + ", energia: " + this.energia + "}");
    }
}
