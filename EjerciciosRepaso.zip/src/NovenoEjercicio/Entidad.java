package NovenoEjercicio;

public class Entidad implements Interactuable {

    private String nombre;
    private int vida;

    public Entidad(String nombre, int vida) {
        this.nombre = nombre;
        this.vida = vida;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getVida() {
        return vida;
    }

    public void setVida(int vida) {
        this.vida = vida;
    }

    public void estadoActual() {
        System.out.println("Producto: {nombre: " + this.nombre + ", vida: " + this.vida + "}");
    }
    public void accionRapida() {
        System.out.println("Si el personaje tiene mas de 30 de vida");
    }
}
