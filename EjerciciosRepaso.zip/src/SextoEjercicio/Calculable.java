package SextoEjercicio;

public interface Calculable {

    void calcularArea();

}
