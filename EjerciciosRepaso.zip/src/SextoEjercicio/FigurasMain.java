package SextoEjercicio;

import java.util.ArrayList;

public class FigurasMain {

    public static void main(String[] args) {

        ArrayList<Figura> lista = new ArrayList<>();

        Triangulo triangulo = new Triangulo("rojo", "Triangulo", 10, 15);
        triangulo.calcularArea();

        Cuadrado cuadrado = new Cuadrado("verde", "Cuadrado", 8);
        cuadrado.calcularArea();

        lista.add(cuadrado);
        lista.add(triangulo);

    }
}
