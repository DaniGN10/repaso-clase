package FileReaderClase;

public class Alumno extends Persona {

    private int nota;

    public Alumno(String nombre, String tipo, int nota) {
        super(nombre, tipo);
        this.nota = nota;
    }

    public int getNota() {
        return nota;
    }

    public void setNota(int nota) {
        this.nota = nota;
    }

    @Override
    public String toString() {
        return "Persona{" +
                "nombre='" + this.getNombre() + '\'' +
                ", tipo='" + this.getTipo() + '\'' +
                ", nota='" + this.nota + '\'' +
                '}';
    }
}
