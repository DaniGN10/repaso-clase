package FileReaderClase;

public class Profesor extends Persona {

    private int valoracion;

    public Profesor(String nombre, String tipo, int valoracion) {
        super(nombre, tipo);
        if (valoracion > 5) {
            this.valoracion = 5;
        }
        else {
            this.valoracion = valoracion;
        }
    }

    public int getValoracion() {
        return valoracion;
    }

    public void setValoracion(int valoracion) {
        this.valoracion = valoracion;
    }

    @Override
    public String toString() {
        return "Persona{" +
                "nombre='" + this.getNombre() + '\'' +
                ", tipo='" + this.getTipo() + '\'' +
                ", valoracion='" + this.valoracion + '\'' +
                '}';
    }
}
