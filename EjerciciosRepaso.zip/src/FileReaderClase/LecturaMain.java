package FileReaderClase;

import java.io.File;

public class LecturaMain {

    public static void main(String[] args) {
        ArchivoDeAccion archivo = new ArchivoDeAccion();
        File arch = new File("src/FileReaderClase/estudiantes.txt");

        archivo.leerArchivo(arch);
        archivo.verDatosArray();
        archivo.escribirArchivo();
    }
}
