package FileReaderClase;

import java.io.*;
import java.util.ArrayList;

// Archivo donde implementaremos el ArrayList, los codigo de lectura, escritura, etc.
public class ArchivoDeAccion {

    private ArrayList<Persona> personas;

    public ArchivoDeAccion() {
        this.personas = new ArrayList<>();
    }

    public ArrayList<Persona> getPersonas() {
        return personas;
    }

    public void setPersonas(ArrayList<Persona> personas) {
        this.personas = personas;
    }

    public void leerArchivo(File archivo) {
        /*
         * 1- Leer el archivo
         * 2- Crear objote alumno o profesor
         * 3- Añadir objetos al ArrayList
         * */

        System.out.println(archivo.length());
        if (archivo.exists()) { //esto solo se pone si lo pido
            try (BufferedReader bufferedReader = new BufferedReader(new FileReader(archivo))) {
                String line;
                while ((line = bufferedReader.readLine()) != null) {
                    String[] partes = line.split("\\|");
                    if (partes[1].equals("Alumno")) {
                        this.personas.add(
                                new Alumno(partes[0], partes[1], Integer.parseInt(partes[2]))
                        );
                    } else {
                       this.personas.add(
                               new Profesor(partes[0], partes[1], Integer.parseInt(partes[2]))
                       );
                    }
                }
            } catch (IOException e) {
                System.out.println("Error: " + e.getMessage());
            }
        } else {
            try {
                if (archivo.createNewFile()) {
                    System.out.println("Archivo creado correctamente");
                }
            }
            catch (IOException e) {
                System.out.println("Error creando archivo: " + e.getMessage());
            }
        }


    }

    public void escribirArchivo() {
        try (BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter("src/FileReaderClase/estudiantes2.txt"))) {
            for (int i = 0; i < this.personas.size(); i++) {
                bufferedWriter.write(this.personas.get(i).toString());
                bufferedWriter.newLine();
            }
        }
        catch (IOException e) {
            System.out.println("Error escritura: " + e.getMessage());
        }
    }

    public void verDatosArray() {
        for (int i = 0; i < this.personas.size(); i++) {
            System.out.println(this.personas.get(i).toString());
        }
    }
}
