package TercerEjercicio;

public class EstudianteUniversitario extends Estudiante {

    private String nombreUniversidad;

    public EstudianteUniversitario(String nombre, int numeroIdentificacion, String nombreUniversidad) {
        super(nombre, numeroIdentificacion);
        this.nombreUniversidad = nombreUniversidad;
    }

    public String getNombreUniversidad() {
        return nombreUniversidad;
    }

    public void setNombreUniversidad(String nombreUniversidad) {
        this.nombreUniversidad = nombreUniversidad;
    }
}
