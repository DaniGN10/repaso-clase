package TercerEjercicio;

public class EstudiantesMain {

    public static void main(String[] args) {

        Estudiante Sergio = new Estudiante("Sergio", 2804);
    }
}
