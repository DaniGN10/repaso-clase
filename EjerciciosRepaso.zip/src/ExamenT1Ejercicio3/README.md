3. (2 puntos) Desarrolla un programa que gestione las notas de estudiantes en un archivo
   de texto. El programa debe leer las notas desde un archivo, agregar nuevas notas
   predefinidas y luego escribir el archivo actualizado. Además, debe verificar la existencia
   del archivo, crear uno si no existe, y mostrar el tamaño del archivo final. El archivo será
   uno documento de texto (.txt).
   • Requisitos
   o Clase Estudiante:
   § atributos (String nombre, double nota).
   § Incluye un método toString() que devuelva los datos del estudiante
   en el formato: "[nombre | [nota]"

o Clase GestorNotas:
§ Implementa métodos para gestionar el archivo de notas de los
estudiantes utilizando FileReader, FileWriter y File.

o Métodos requeridos:
§ void verificarYCrearArchivo(File rutaArchivo): Verifica si el archivo de
notas existe en la ruta especificada. Si no existe, crea un nuevo
archivo. Si el archivo existe imprime por consola “El archivo ya existe
en la ruta especificada”.
§ leerNotas(File rutaArchivo): Lee las notas de estudiantes desde el
archivo utilizando FileReader. Cada línea representa a un estudiante,
y el método debe devolver una lista de objetos de tipo Estudiante.
§ Escribe nuevas lineas al final del archivo usando FileWriter sin
sobrescribir el contenido ya existente.
§ void mostrarInfoArchivo(File rutaArchivo): Muestra en pantalla:
• Si el archivo existe o no.
• Su tamaño en bytes.

El archivo se llamará notas_estudiantes.txt y tendrán una estructura:

Juan Perez | 8.5
Ana Lopez | 7.5 