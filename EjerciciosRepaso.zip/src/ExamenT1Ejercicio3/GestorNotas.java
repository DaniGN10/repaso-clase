package ExamenT1Ejercicio3;

import java.util.ArrayList;

public class GestorNotas {

    private ArrayList<Estudiante> estudiantes;

    public GestorNotas() {
        this.estudiantes = new ArrayList<>();
    }

    public ArrayList<Estudiante> getEstudiantes() {
        return estudiantes;
    }
    public void setEstudiantes(ArrayList<Estudiante> estudiantes) {
        this.estudiantes = estudiantes;
    }

    public void verificarYCrearArchivo() {

    }
}
