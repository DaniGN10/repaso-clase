package SeptimoEjercicio;

public interface ElementosBiblioteca {

    String getTipo();
}
