package SeptimoEjercicio;

public class Libro extends MaterialLectura {

    public Libro(String titulo, String autor) {
        super(titulo, autor);
    }

    @Override
    public String getTipo() {
        return "Libro";
    }
}
