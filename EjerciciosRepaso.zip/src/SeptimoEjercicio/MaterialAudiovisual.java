package SeptimoEjercicio;

public class MaterialAudiovisual implements ElementosBiblioteca {

    private String titulo;
    private int duracionMinutos;

    public MaterialAudiovisual(String titulo, int duracionMinutos) {
        this.titulo = titulo;
        this.duracionMinutos = duracionMinutos;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public int getDuracionMinutos() {
        return duracionMinutos;
    }

    public void setDuracionMinutos(int duracionMinutos) {
        this.duracionMinutos = duracionMinutos;
    }

    public String getTipo() {
        return "No tenemos datos";
    }
}
