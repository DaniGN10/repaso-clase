package SeptimoEjercicio;

public class AudioLibro extends MaterialLectura {

    public AudioLibro(String titulo, String autor) {
        super(titulo, autor);
    }

    @Override
    public String getTipo() {
        return "AudioLibro";
    }
}
