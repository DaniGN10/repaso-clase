package SeptimoEjercicio;

public class Video extends MaterialAudiovisual {

    public Video(String titulo, int duracionMinutos) {
        super(titulo, duracionMinutos);
    }

    @Override
    public String getTipo() {
        return "Video";
    }
}
