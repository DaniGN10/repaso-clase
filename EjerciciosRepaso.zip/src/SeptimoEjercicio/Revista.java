package SeptimoEjercicio;

public class Revista extends MaterialLectura {

    public Revista(String titulo, String autor) {
        super(titulo, autor);
    }

    @Override
    public String getTipo() {
       return "Revista";
    }
}
