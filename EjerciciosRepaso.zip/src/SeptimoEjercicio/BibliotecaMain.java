package SeptimoEjercicio;

import java.util.ArrayList;

public class BibliotecaMain {

    public static void main(String[] args) {

        ArrayList<ElementosBiblioteca> lista = new ArrayList<>();

        MaterialLectura libro = new MaterialLectura("La Gaviota", "Anton Chejov");
        MaterialAudiovisual video = new MaterialAudiovisual("La Gaviota", 20);

        lista.add(libro);
        lista.add(video);

        for (ElementosBiblioteca elemento : lista) {
            System.out.println(elemento.getTipo());
        }

        System.out.println();
        for (int i = 0; i < lista.size(); i++) {
            System.out.println(lista.get(i).getTipo());
        }
    }
}
